import torch
import numpy as np
import random
from random import shuffle

def toarray(x):
    return torch.from_numpy(np.array(list(x)).astype(np.int32))
def toarray_float(x):
    return torch.from_numpy(np.array(list(x)).astype(np.float))

def get_neighbor_id(ent, h2t, t2h, A):
    hrt = []
    hrt1 = []
    hrt2 = []
    if ent in h2t.keys():
        tails = list(h2t[ent])
        hrt1 = [(ent, A[(ent, i)], i) for i in tails]
    if ent in t2h.keys():
        heads = list(t2h[ent])
        hrt2 = [(i, A[(i, ent)], ent) for i in heads]
    hrt = hrt1 + hrt2
    return hrt

def get_triple_neighbor(h,r,t,dataset,num_neighbor):
    h_neighbor = []
    h2t = dataset.h2t
    t2h = dataset.t2h
    A = dataset.A

    head_neighbor = get_neighbor_id(h,h2t,t2h,A)
    tail_neighbor = get_neighbor_id(t,h2t,t2h,A)

    # Generating hh_neighbors
    if len(head_neighbor) >= num_neighbor:
        hh_neighbors = random.sample(head_neighbor, k=num_neighbor) if len(
            head_neighbor) > num_neighbor else head_neighbor
    else:
        hh_neighbors = random.choices(head_neighbor if head_neighbor else [(h, r, t)], k=num_neighbor)

    # Generating tt_neighbors
    if len(tail_neighbor) >= num_neighbor:
        tt_neighbors = random.sample(tail_neighbor, k=num_neighbor) if len(
            tail_neighbor) > num_neighbor else tail_neighbor
    else:
        tt_neighbors = random.choices(tail_neighbor if tail_neighbor else [(h, r, t)], k=num_neighbor)

    hrt_neighbor = [(h,r,t)] + hh_neighbors + [(h,r,t)] + tt_neighbors
    return hrt_neighbor

def get_triple_batch(args, dataset, batch_size, num_neighbor):
    h, r, t, all_triples, labels, A = dataset.next_batch()
    labels = labels.unsqueeze(1)
    all_triples_labels = torch.cat((all_triples, labels), dim=1)
    print('all_triples_labels.shape', all_triples_labels.shape)

    sample_triple_labels = random.sample(list(all_triples_labels), k=batch_size)
    batch_triples = []
    batch_labels = []
    for i in range(batch_size):
        hrt_neighbor = get_triple_neighbor(sample_triple_labels[i][0].item(), sample_triple_labels[i][1].item(),
                                           sample_triple_labels[i][2].item(), dataset, num_neighbor)
        batch_triples = batch_triples + hrt_neighbor
        batch_labels.append(sample_triple_labels[i][3])
    print('batch_triples', batch_triples)
    ent_vec, rel_vec = dataset.ent_vec, dataset.rel_vec
    head_embedding = np.array([ent_vec[batch_triples[i][0]] for i in range(len(batch_triples))])
    head_embedding = torch.from_numpy(head_embedding)
    relation_embedding = np.array([rel_vec[batch_triples[i][1]] for i in range(len(batch_triples))])
    relation_embedding = torch.from_numpy(relation_embedding)
    tail_embedding = np.array([ent_vec[batch_triples[i][2]] for i in range(len(batch_triples))])
    tail_embedding = torch.from_numpy(tail_embedding)

    batch_triples_emb = torch.cat((head_embedding, relation_embedding), dim=1)
    batch_triples_emb = torch.cat((batch_triples_emb, tail_embedding), dim=1)

    batch_triples_emb = batch_triples_emb.view(-1, 3, args.BiLSTM_input_size)
    print('input_batch.shape:', batch_triples_emb.shape)

    return batch_triples_emb, toarray(batch_triples), toarray(batch_labels)

def get_batch_only(dataset, batch_size, start_id):
    triples, labels = dataset.get_data_embed()

    if start_id + batch_size >= len(triples):
        batch_triples = triples[start_id:]
        batch_labels = labels[start_id:]
        start_id = 0
    else:
        batch_triples = triples[start_id:start_id + batch_size]
        batch_labels = labels[start_id:start_id + batch_size]
        start_id = start_id + batch_size
    return batch_triples, batch_labels, start_id

def get_triple_pair(dataset, batch_size, num_neighbor):
    h, r, t, all_triples, labels, A = dataset.get_data()
    labels = labels.unsqueeze(1)
    all_triples_labels = torch.cat((all_triples, labels), dim=1)

    n = all_triples_labels.size(0) // 2
    idx = random.randint(0, n - 1)
    sample_triple_labels = [all_triples_labels[idx], all_triples_labels[idx + n]]
    batch_triples = []
    batch_labels = []

    for i in range(batch_size * 2):
        hrt_neighbor = get_triple_neighbor(sample_triple_labels[i][0].item(), sample_triple_labels[i][1].item(),
                                           sample_triple_labels[i][2].item(), dataset, num_neighbor)
        batch_triples = batch_triples + hrt_neighbor
        batch_labels.append(sample_triple_labels[i][3])

    ent_vec, rel_vec = dataset.ent_vec, dataset.rel_vec

    # 获取嵌入向量
    head_embedding = np.array([ent_vec[batch_triples[i][0]] for i in range(len(batch_triples))])
    head_embedding = torch.from_numpy(head_embedding)
    relation_embedding = np.array([rel_vec[batch_triples[i][1]] for i in range(len(batch_triples))])
    relation_embedding = torch.from_numpy(relation_embedding)
    tail_embedding = np.array([ent_vec[batch_triples[i][2]] for i in range(len(batch_triples))])
    tail_embedding = torch.from_numpy(tail_embedding)
    # 拼接嵌入向量
    batch_triples_emb = torch.cat((head_embedding, relation_embedding), dim=1)
    batch_triples_emb = torch.cat((batch_triples_emb, tail_embedding), dim=1)

    batch_triples_emb = batch_triples_emb.view(-1, 3, 100)
    # print('input_batch.shape:', batch_triples_emb.shape)

    return batch_triples_emb, toarray(batch_triples), toarray(batch_labels)

def get_pair_batch_train(args, dataset, batch_size, num_neighbor):
    all_triples = dataset.train_data

    n = all_triples.size(0) // 2
    sample_triple = []
    for i in range(batch_size):
        idx = random.randint(0, n - 1)
        temp = [all_triples[idx], all_triples[idx + n]]
        sample_triple += temp

    batch_triples = []
    for i in range(batch_size * 2):
        hrt_neighbor = get_triple_neighbor(sample_triple[i][0].item(), sample_triple[i][1].item(),
                                           sample_triple[i][2].item(), dataset, num_neighbor)
        batch_triples = batch_triples + hrt_neighbor
    ent_vec, rel_vec = dataset.ent_vec, dataset.rel_vec

    head_embedding = np.array([ent_vec[batch_triples[i][0]] for i in range(len(batch_triples))])
    head_embedding = torch.from_numpy(head_embedding)
    relation_embedding = np.array([rel_vec[batch_triples[i][1]] for i in range(len(batch_triples))])
    relation_embedding = torch.from_numpy(relation_embedding)
    tail_embedding = np.array([ent_vec[batch_triples[i][2]] for i in range(len(batch_triples))])
    tail_embedding = torch.from_numpy(tail_embedding)
    batch_triples_emb = torch.cat((head_embedding, relation_embedding), dim=1)
    batch_triples_emb = torch.cat((batch_triples_emb, tail_embedding), dim=1)

    batch_triples_emb = batch_triples_emb.view(-1, 3, args.BiLSTM_input_size)

    return batch_triples_emb, toarray(batch_triples)

#根据索引 train_idx 从 all_triples 中获取一批次的头、关系、尾和标签。用于基线模型的批次生成
def get_batch_baseline(args, all_triples, train_idx, n_batch):

    if n_batch == 0:
        np.random.shuffle(train_idx)
    if (n_batch + 1) * args.batch_size > len(train_idx):
        ids = train_idx[n_batch * args.batch_size:]
        # length = len(train_idx) - n_batch * args.batch_size
    else:
        ids = train_idx[n_batch * args.batch_size: (n_batch + 1) * args.batch_size]

    # train_pos = all_triples[0:len(all_triples) // 2, :]
    # train_neg = all_triples[len(all_triples) // 2:, :]

    batch_h = np.append(np.array([all_triples[i][0] for i in ids]),
                        np.array([all_triples[i + len(all_triples) // 2][0] for i in ids]))
    batch_r = np.append(np.array([all_triples[i][1] for i in ids]),
                        np.array([all_triples[i + len(all_triples) // 2][1] for i in ids]))
    batch_t = np.append(np.array([all_triples[i][2] for i in ids]),
                        np.array([all_triples[i + len(all_triples) // 2][2] for i in ids]))

    batch_y = np.concatenate((np.ones(args.batch_size), -1 * np.ones(args.batch_size)))

    return batch_h, batch_t, batch_r, batch_y
# return toarray(batch_h), toarray(batch_t), toarray(batch_r), toarray(batch_y)

#与 get_batch_baseline 类似，但还返回标签数组 label。
def get_batch_baseline_test(args, all_triples, labels, train_idx, n_batch):
    if n_batch == 0:
        np.random.shuffle(train_idx)
    if (n_batch + 1) * args.batch_size > len(train_idx):
        ids = train_idx[n_batch * args.batch_size:]
        # length = len(train_idx) - n_batch * args.batch_size
    else:
        ids = train_idx[n_batch * args.batch_size: (n_batch + 1) * args.batch_size]
    # ids = train_idx[n_batch * args.batch_size: (n_batch + 1) * args.batch_size]

    batch_h = np.append(np.array([all_triples[i][0] for i in ids]),
                        np.array([all_triples[i + len(all_triples) // 2][0] for i in ids]))
    batch_r = np.append(np.array([all_triples[i][1] for i in ids]),
                        np.array([all_triples[i + len(all_triples) // 2][1] for i in ids]))
    batch_t = np.append(np.array([all_triples[i][2] for i in ids]),
                        np.array([all_triples[i + len(all_triples) // 2][2] for i in ids]))

    batch_y = np.concatenate((np.ones(args.batch_size), -1 * np.ones(args.batch_size)))
    label = np.array([labels[i] for i in ids])

    return batch_h, batch_t, batch_r, batch_y, label

#从训练数据集中获取一对三元组，并获取其邻居三元组。与 get_pair_batch_train 类似，但增加了对批次索引的处理和断言检查。
def get_pair_batch_train_common(args, dataset, n_batch, train_idx, batch_size, num_neighbor):
    all_triples = dataset.train_data
    if n_batch == 0:
        np.random.shuffle(train_idx)
    length = batch_size
    if (n_batch + 1) * batch_size > len(train_idx):
        ids = train_idx[n_batch * batch_size:]
        length = len(train_idx) - n_batch * batch_size
    else:
        ids = train_idx[n_batch * batch_size: (n_batch + 1) * batch_size]
    assert length == len(ids), "ERROR: batch_size != length."

    n = all_triples.size(0) // 2
    sample_triple = []
    for i in range(len(ids)):
        idx = ids[i]
        temp = [all_triples[idx], all_triples[idx + n]]
        sample_triple += temp

    batch_triples = []
    for i in range(len(sample_triple)):
        hrt_neighbor = get_triple_neighbor(sample_triple[i][0].item(), sample_triple[i][1].item(), sample_triple[i][2].item(), dataset, num_neighbor)
        batch_triples = batch_triples + hrt_neighbor

    batch_h = np.array([batch_triples[i][0] for i in range(len(batch_triples))])
    batch_r = np.array([batch_triples[i][1] for i in range(len(batch_triples))])
    batch_t = np.array([batch_triples[i][2] for i in range(len(batch_triples))])

    return batch_h, batch_r, batch_t, length



def get_pair_batch_test(dataset, batch_size, num_neighbor, start_id):
    all_triples = dataset.triples_with_anomalies
    labels = dataset.triples_with_anomalies_labels
    labels = labels.unsqueeze(1)

    length = batch_size
    if start_id + batch_size > len(all_triples):
        sample_triple = all_triples[start_id:]
        batch_labels = labels[start_id:]
        length = len(sample_triple)
        start_id = 0
    else:
        sample_triple = all_triples[start_id: start_id + batch_size]
        batch_labels = labels[start_id: start_id + batch_size]
        start_id += batch_size

    batch_triples = []
    for i in range(len(sample_triple)):
        hrt_neighbor = get_triple_neighbor(sample_triple[i][0].item(), sample_triple[i][1].item(), sample_triple[i][2].item(), dataset, num_neighbor)
        batch_triples = batch_triples + hrt_neighbor

    batch_h = np.array([batch_triples[i][0] for i in range(len(batch_triples))])
    batch_r = np.array([batch_triples[i][1] for i in range(len(batch_triples))])
    batch_t = np.array([batch_triples[i][2] for i in range(len(batch_triples))])
    print("batch_r shape:", batch_r.shape)

    batch_labels = torch.LongTensor(batch_labels.view(-1).cpu().numpy())

    return batch_h, batch_r, batch_t, batch_labels, start_id, length
























