"""
在最优超参数组合（lr=0.01,gama=0.1,mu=0.001）,最好的就是tau=0.5
"""

import numpy as np
import torch
import os
import logging
import math
import argparse
import random
from dataset import Reader
from create_batch import get_pair_batch_train_common, get_pair_batch_test, toarray
from model import BiLSTM_Attention
import torch.nn as nn
import torch.nn.functional as F


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--model', default='CAGED', help='model name')
    parser.add_argument('--seed', default=0, type=int, help='random seed')
    parser.add_argument('--mode', default='test', choices=['train', 'test'], help='run training or evaluation')
    parser.add_argument('-ds', '--dataset', default='WN18RR', help='dataset')
    args, _ = parser.parse_known_args()
    parser.add_argument('--save_dir', default=f'./checkpoints/{args.dataset}/', help='model output directory')
    parser.add_argument('--save_model', dest='save_model', action='store_true')
    parser.add_argument('--load_model_path', default=f'./checkpoints/{args.dataset}')
    parser.add_argument('--log_folder', default=f'./checkpoints/{args.dataset}/', help='model output directory')

    # data
    parser.add_argument('--data_path', default=f'./data/{args.dataset}/', help='path to the dataset')
    parser.add_argument('--dir_emb_ent', default="entity2vec.txt", help='pretrain entity embeddings')
    parser.add_argument('--dir_emb_rel', default="relation2vec.txt", help='pretrain entity embeddings')
    parser.add_argument('--num_batch', default=2740, type=int, help='number of batch')
    parser.add_argument('--num_train', default=0, type=int, help='number of triples')
    parser.add_argument('--batch_size', default=256, type=int, help='batch size')
    parser.add_argument('--total_ent', default=0, type=int, help='number of entities')
    parser.add_argument('--total_rel', default=0, type=int, help='number of relations')

    # model architecture
    parser.add_argument('--BiLSTM_input_size', default=100, type=int, help='BiLSTM input size')
    parser.add_argument('--BiLSTM_hidden_size', default=100, type=int, help='BiLSTM hidden size')
    parser.add_argument('--BiLSTM_num_layers', default=2, type=int, help='BiLSTM layers')
    parser.add_argument('--BiLSTM_num_classes', default=1, type=int, help='BiLSTM class')
    parser.add_argument('--num_neighbor', default=39, type=int, help='number of neighbors')
    parser.add_argument('--embedding_dim', default=100, type=int, help='embedding dim')

    # regularization
    parser.add_argument('--alpha', type=float, default=0.2, help='hyperparameter alpha')
    parser.add_argument('--dropout', type=float, default=0.2, help='dropout for EaGNN')

    # optimization
    parser.add_argument('--max_epoch', default=6, help='max epochs')
    parser.add_argument('--learning_rate', default=0.01, type=float, help='learning rate')#best
    parser.add_argument('--gama', default=0.1, type=float, help="margin parameter")#best
    parser.add_argument('--lam', default=0.1, type=float, help="trade-off parameter")
    parser.add_argument('--mu', default=0.001, type=float, help="gated attention parameter")#best
    parser.add_argument('--anomaly_ratio', default=0.05, type=float, help="anomaly ratio")
    parser.add_argument('--num_anomaly_num', default=300, type=int, help="number of anomalies")
    args = parser.parse_args()

    # 定义一组 tau 值进行测试
    tau_values = [0.1, 0.3, 0.5, 0.7, 1.0]

    # 保存结果的变量
    best_tau = None
    best_performance = -float('inf')
    performance = None  # 初始化 performance

    # 记录结果的文件
    result_file = os.path.join(args.log_folder, "grid_search_results.txt")

    for tau in tau_values:
        args.tau = tau
        logging.info(f"Testing tau={tau}")

        # 设置随机种子和设备
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        if torch.cuda.is_available():
            torch.cuda.manual_seed(args.seed)

        # 加载数据
        dataset = Reader(args, args.data_path)

        # 训练和测试
        if args.mode == 'train':
            train(args, dataset, device)
        elif args.mode == 'test':
            model_saved_path = os.path.join(args.save_dir, f'{args.model}_{args.dataset}_{args.anomaly_ratio}_tau_{tau}.ckpt')
            # 在加载模型之前检查路径是否存在
            if not os.path.exists(model_saved_path):
                raise FileNotFoundError(f"Model file not found at: {model_saved_path}")
            performance = test(args, dataset, device)
        else:
            raise ValueError('Invalid mode')

        # 比较并记录最佳参数
        if performance is not None and performance > best_performance:
            best_performance = performance
            best_tau = tau

        with open(result_file, 'a') as f:
            f.write(f"tau={tau}, performance={performance}\n")

    logging.info(f"Best tau={best_tau} with performance={best_performance}")




def contrastive_loss(z0, z1, tau=0.5):
    # 计算余弦相似度
    z0 = F.normalize(z0, dim=1)
    z1 = F.normalize(z1, dim=1)

    # 计算相似度矩阵
    sim_matrix = torch.matmul(z0, z1.T) / tau

    # 构造标签，正样本对的标签为对角线上的1，其他为0
    batch_size = z0.size(0)
    labels = torch.arange(batch_size).to(sim_matrix.device)

    # 计算对比损失
    loss = F.cross_entropy(sim_matrix, labels)
    return loss


def train(args, dataset, device):
    # 数据集参数和模型初始化
    data_path = args.data_path
    model_name = args.model
    all_triples = dataset.train_data
    train_idx = list(range(len(all_triples) // 2))
    num_iterations = math.ceil(dataset.num_triples_with_anomalies / args.batch_size)
    total_num_anomalies = dataset.num_anomalies
    logging.basicConfig(level=logging.INFO)
    file_handler = logging.FileHandler(os.path.join(args.log_folder, model_name + "_" + args.dataset + "_" + str(
        args.anomaly_ratio) + "_Neighbors" + str(args.num_neighbor) + "_" + "_log.txt"))
    logger = logging.getLogger()
    logger.addHandler(file_handler)
    logging.info('There are %d Triples with %d anomalies in the graph.' % (len(dataset.labels), total_num_anomalies))

    args.total_ent = dataset.num_entity
    args.total_rel = dataset.num_relation

    # 创建模型
    model = BiLSTM_Attention(args, args.BiLSTM_input_size, args.BiLSTM_hidden_size, args.BiLSTM_num_layers,
                             args.dropout, args.alpha, args.mu, device).to(device)

    # 定义损失函数和优化器
    criterion = nn.MarginRankingLoss(args.gama)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)

    for k in range(args.max_epoch):
        for it in range(num_iterations):
            # 获取训练数据
            batch_h, batch_r, batch_t, batch_size = get_pair_batch_train_common(args, dataset, it, train_idx,
                                                                                args.batch_size, args.num_neighbor)

            batch_h = torch.LongTensor(batch_h).to(device)
            batch_t = torch.LongTensor(batch_t).to(device)
            batch_r = torch.LongTensor(batch_r).to(device)

            # 前向传播
            out, out_att = model(batch_h, batch_r, batch_t)

            out = out.reshape(batch_size, -1, 2 * 3 * args.BiLSTM_hidden_size)
            out_att = out_att.reshape(batch_size, -1, 2 * 3 * args.BiLSTM_hidden_size)

            pos_h = out[:, 0, :]
            pos_z0 = out_att[:, 0, :]
            pos_z1 = out_att[:, 1, :]
            neg_h = out[:, 1, :]
            neg_z0 = out_att[:, 2, :]
            neg_z1 = out_att[:, 3, :]

            # 计算损失
            pos_loss1 = contrastive_loss(pos_z0, pos_z1, tau=args.tau)
            neg_loss1 = contrastive_loss(neg_z0, neg_z1, tau=args.tau)

            pos_loss2 = torch.norm(pos_h[:, 0:2 * args.BiLSTM_hidden_size] + pos_h[:, 2 * args.BiLSTM_hidden_size:2 * 2 * args.BiLSTM_hidden_size] - pos_h[:, 2 * 2 * args.BiLSTM_hidden_size:2 * 3 * args.BiLSTM_hidden_size], p=2, dim=1)
            neg_loss2 = torch.norm(neg_h[:, 0:2 * args.BiLSTM_hidden_size] + neg_h[:, 2 * args.BiLSTM_hidden_size:2 * 2 * args.BiLSTM_hidden_size] - neg_h[:, 2 * 2 * args.BiLSTM_hidden_size:2 * 3 * args.BiLSTM_hidden_size], p=2, dim=1)

            y = -torch.ones(batch_size).to(device)
            loss1 = criterion(pos_loss2, neg_loss2, y)
            loss = pos_loss1 + neg_loss1 + loss1

            # 反向传播和优化
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            logging.info('Epoch: %d-%d, Loss: %f' % (k, it + 1, loss.item()))

    # 训练结束后保存模型
    model_saved_path = os.path.join(args.save_dir, f'{args.model}_{args.dataset}_{args.anomaly_ratio}_tau_{args.tau}.ckpt')
    torch.save(model.state_dict(), model_saved_path)
    logging.info(f"Model saved at {model_saved_path}")

def test(args, dataset, device):
    device = torch.device('cpu')
    model_name = args.model
    all_triples = dataset.train_data
    train_idx = list(range(len(all_triples) // 2))
    num_iterations = math.ceil(dataset.num_triples_with_anomalies / args.batch_size)
    total_num_anomalies = dataset.num_anomalies
    logging.basicConfig(level=logging.INFO)
    file_handler = logging.FileHandler(os.path.join(args.log_folder, model_name + "_" + args.dataset + "_" + str(
        args.anomaly_ratio) + "_Neighbors" + str(args.num_neighbor) + "_" + "_log.txt"))
    logger = logging.getLogger()
    logger.addHandler(file_handler)
    logging.info('There are %d Triples with %d anomalies in the graph.' % (len(dataset.labels), total_num_anomalies))

    args.total_ent = dataset.num_entity
    args.total_rel = dataset.num_relation

    # 生成正确的模型路径，确保与保存时一致
    model_saved_path = os.path.join(args.save_dir, f'{args.model}_{args.dataset}_{args.anomaly_ratio}_tau_{args.tau}.ckpt')
    logging.info(f"Loading model from {model_saved_path}")

    # 检查文件是否存在
    if not os.path.exists(model_saved_path):
        raise FileNotFoundError(f"Model file not found at: {model_saved_path}")

    # 加载模型
    model1 = BiLSTM_Attention(args, args.BiLSTM_input_size, args.BiLSTM_hidden_size, args.BiLSTM_num_layers,
                              args.dropout, args.alpha, args.mu, device).to(device)
    model1.load_state_dict(torch.load(model_saved_path))
    model1.eval()

    with torch.no_grad():
        all_loss = []
        all_label = []
        start_id = 0

        for i in range(num_iterations):
            batch_h, batch_r, batch_t, labels, start_id, batch_size = get_pair_batch_test(dataset, args.batch_size,
                                                                                          args.num_neighbor, start_id)

            batch_h = torch.LongTensor(batch_h).to(device)
            batch_t = torch.LongTensor(batch_t).to(device)
            batch_r = torch.LongTensor(batch_r).to(device)
            labels = labels.to(device)

            out, out_att = model1(batch_h, batch_r, batch_t)
            out_att = out_att.reshape(batch_size, 2, 2 * 3 * args.BiLSTM_hidden_size)
            out_att_view0 = out_att[:, 0, :]
            out_att_view1 = out_att[:, 1, :]

            loss1 = contrastive_loss(out_att_view0, out_att_view1, tau=args.tau)

            loss2 = torch.norm(out[:, 0:2 * args.BiLSTM_hidden_size] + out[:,
                                                                       2 * args.BiLSTM_hidden_size:2 * 2 * args.BiLSTM_hidden_size] - out[
                                                                                                                                      :,
                                                                                                                                      2 * 2 * args.BiLSTM_hidden_size:2 * 3 * args.BiLSTM_hidden_size],
                               p=2, dim=1)

            loss = loss1 + loss2

            all_loss.append(loss)
            all_label.append(labels)

            logging.info('[Test] Evaluation on %d batch of Original graph' % i)

        total_num = len(all_label)

        max_top_k = total_num_anomalies * 2
        all_loss = torch.cat(all_loss)  # 将所有批次的损失拼接起来
        all_label = torch.cat(all_label)

        top_loss, top_indices = torch.topk(all_loss, max_top_k, largest=True, sorted=True)
        top_labels = toarray([all_label[top_indices[i]] for i in range(len(top_indices))])

        anomaly_discovered = []
        for i in range(max_top_k):
            if i == 0:
                anomaly_discovered.append(top_labels[i])
            else:
                anomaly_discovered.append(anomaly_discovered[i - 1] + top_labels[i])

        results_interval_10 = np.array([anomaly_discovered[i * 10] for i in range(max_top_k // 10)])
        logging.info('[Test] final results: %s' % str(results_interval_10))

        top_k = np.arange(1, max_top_k + 1)

        assert len(top_k) == len(anomaly_discovered), 'The size of result list is wrong'

        precision_k = np.array(anomaly_discovered) / top_k
        recall_k = np.array(anomaly_discovered) * 1.0 / total_num_anomalies

        precision_interval_10 = [precision_k[i * 10] for i in range(max_top_k // 10)]
        logging.info('[Test] final Precision: %s' % str(precision_interval_10))
        recall_interval_10 = [recall_k[i * 10] for i in range(max_top_k // 10)]
        logging.info('[Test] final Recall: %s' % str(recall_interval_10))

        # 计算 ratios 指标
        logging.info('K = %d' % args.max_epoch)
        ratios = [0.001, 0.005, 0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 0.11, 0.12, 0.13, 0.14, 0.15,
                  0.20, 0.30, 0.45]
        for i in range(len(ratios)):
            num_k = int(ratios[i] * dataset.num_original_triples)

            if num_k > len(anomaly_discovered):
                break

            recall = anomaly_discovered[num_k - 1] * 1.0 / total_num_anomalies
            precision = anomaly_discovered[num_k - 1] * 1.0 / num_k

            logging.info(
                '[Test][%s][%s] Precision %f -- %f : %f' % (
                args.dataset, model_name, args.anomaly_ratio, ratios[i], precision))
            logging.info('[Test][%s][%s] Recall  %f-- %f : %f' % (
            args.dataset, model_name, args.anomaly_ratio, ratios[i], recall))
            logging.info('[Test][%s][%s] anomalies in total: %d -- discovered:%d -- K : %d' % (
                args.dataset, model_name, total_num_anomalies, anomaly_discovered[num_k - 1], num_k))

        # 以 performance 为指标
        return np.mean(precision_interval_10)  # 返回平均精度作为 performance


if __name__ == '__main__':
    # 配置日志
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    logging.info('Starting main function...')

    main()

