import torch
import torch.nn as nn
from torch.nn import functional as F
import numpy as np

class GraphAttentionLayer1(nn.Module):
    def __init__(self, in_features, out_features, dropout, alpha, mu=0.001, concat=False):
        super(GraphAttentionLayer1, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.dropout = dropout
        self.alpha = alpha
        self.concat = concat
        self.mu = mu

        # Initialize weight matrix W and attention vector a
        self.W = nn.Parameter(torch.zeros(size=(in_features, out_features)))
        nn.init.xavier_uniform_(self.W.data, gain=1.414)

        self.a = nn.Parameter(torch.zeros(size=(2 * out_features, 1)))
        nn.init.xavier_uniform_(self.a.data, gain=1.414)

        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, inp):
        # Linear transformation of input features
        h = torch.matmul(inp, self.W)  # Shape: [batch_size, N, out_features]
        N = h.size(1)  # Number of nodes
        B = h.size(0)  # Batch size

        # Create attention mechanism input by repeating the first node's features
        a = h[:, 0, :].unsqueeze(1).repeat(1, N, 1)  # Shape: [batch_size, N, out_features]
        a_input = torch.cat((h, a), dim=2)  # Shape: [batch_size, N, 2*out_features]

        # Compute attention scores
        e = self.leakyrelu(torch.matmul(a_input, self.a))  # Shape: [batch_size, N, 1]

        # Apply softmax to get attention coefficients
        attention = F.softmax(e, dim=1)  # Shape: [batch_size, N, 1]
        attention = attention - self.mu
        attention = (attention + abs(attention)) / 2.0  # Apply ReLU
        attention = F.dropout(attention, self.dropout, training=self.training)  # Apply dropout

        attention = attention.view(B, 1, N)  # Reshape attention scores
        # Apply attention to node features
        h_prime = torch.matmul(attention, h).squeeze(1)  # Shape: [batch_size, out_features]

        if self.concat:
            return F.elu(h_prime)  # Apply activation function if concatenation is True
        else:
            return h_prime  # Return final node features

class BiLSTM_Attention(nn.Module):
    def __init__(self, args, input_size, hidden_size, num_layers, dropout, alpha, mu, device):
        super(BiLSTM_Attention, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.seq_length = 3
        self.BiLSTM_input_size = args.BiLSTM_input_size
        self.num_neighbor = args.num_neighbor
        self.device = device

        # Bidirectional LSTM layer
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, bidirectional=True)

        # Attention layer based on GraphAttentionLayer1
        self.attention = GraphAttentionLayer1(self.hidden_size * 2 * self.seq_length,
                                              self.hidden_size * 2 * self.seq_length,
                                              dropout=dropout, alpha=alpha,
                                              mu=mu, concat=False)

        # Entity and relation embeddings
        self.ent_embeddings = nn.Embedding(args.total_ent, args.embedding_dim)
        self.rel_embeddings = nn.Embedding(args.total_rel, args.embedding_dim)

        # Initialize embeddings uniformly
        uniform_range = 6 / np.sqrt(args.embedding_dim)
        self.ent_embeddings.weight.data.uniform_(-uniform_range, uniform_range)
        self.rel_embeddings.weight.data.uniform_(-uniform_range, uniform_range)

    def forward(self, batch_h, batch_r, batch_t):
        # Get embeddings for head, relation, and tail
        head = self.ent_embeddings(batch_h)
        relation = self.rel_embeddings(batch_r)
        tail = self.ent_embeddings(batch_t)

        # Concatenate head, relation, and tail embeddings
        batch_triples_emb = torch.cat((head, relation, tail), dim=1)
        x = batch_triples_emb.view(-1, 3, self.BiLSTM_input_size)  # Reshape for LSTM input

        # Initialize LSTM hidden state and cell state
        h0 = torch.zeros(self.num_layers * 2, x.size(0), self.hidden_size).to(self.device)  # 2 for bidirectional LSTM
        c0 = torch.zeros(self.num_layers * 2, x.size(0), self.hidden_size).to(self.device)

        # Forward propagate through LSTM
        out, _ = self.lstm(x, (h0, c0))  # Shape: [batch_size, seq_length, hidden_size*2]

        # Reshape LSTM output for attention layer
        out = out.reshape(-1, self.hidden_size * 2 * self.seq_length)
        out = out.reshape(-1, self.num_neighbor + 1, self.hidden_size * 2 * self.seq_length)

        # Apply attention mechanism
        out_att = self.attention(out)  # Shape: [batch_size, dim_embedding]

        # Reshape the final output
        out = out.reshape(-1, self.num_neighbor * 2 + 2, self.hidden_size * 2 * self.seq_length)
        return out[:, 0, :], out_att  # Return first element and attention output
